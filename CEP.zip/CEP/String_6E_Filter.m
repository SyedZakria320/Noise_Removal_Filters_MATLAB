[x, fs] = audioread('6E.m4a');           % Reads audio file
t = 0 : 1/fs : (length(x)-1)/fs;        % Time axis of audio
%sound(x, fs);                          % To hear Audio uncomment sound()

samples = [1 5*fs];                  % Select interval from 1s to 5s
[X, FS] = audioread('6E.m4a', samples);  % Reads audio file from interval
T = 0 : 1/FS : (length(X)-1)/FS;        % Time axis of selected audio
%sound(X, FS);                          % To hear audio uncomment sound

n = length(x);
f_axis = 0 : (n-1)*fs/n;                % Frequency axis of audio
FFT_1 = fft(x, n);
F0_1 = (-n/2 : n/2-1) .* (fs/n);
Y0_1 = fftshift(FFT_1);
AY0_1 = abs(Y0_1);                      % FFT centered at 0

N = length(X);                          % Frequency axis of audio
F_Axis = 0 : (N-1)*FS/N;
FFT_2 = fft(X, N);
F0_2 = (-N/2 : N/2-1) .* (FS/N);
Y0_2 = fftshift(FFT_2);
AY0_2 = abs(Y0_2);                      % FFT centered at 0

subplot(3, 2, 1)
plot(t, x)
title('Original Audio Signal')
xlabel('Time')
ylabel('Amplitude')

subplot(3, 2, 2)
plot(T, X)
title('Selected Audio Signal')
xlabel('Time')
ylabel('Amplitude')

subplot(3, 2, 3)
plot(F0_1, AY0_1)
title('FFT-Original Audio Signal')
xlabel('Frequency(Hz)')
ylabel('Amplitude')

subplot(3, 2, 4)
plot(F0_2, AY0_2)
title('FFT-Selected Audio Signal')
xlabel('Frequency(Hz)')
ylabel('Amplitude')

% Band Pass Filter Design (70 Hz to 330*3 Hz)
% We want to hear sound upto its 3rd harmonic so 82*3 = 246 Hz
% fs1 and fs2 are differ by 10 from fp1 and fp2, you can change this

fp1 = 70;
fs1 = 80;
Fs = 44100;
wp1 =(fp1/Fs)*2*pi ;
ws1 = (fs1/Fs)*2*pi  ;
fp2 = 246;
fs2 = 256;
Fs = 44100;
wp2 = (fp2/Fs)*2*pi ;
ws2 = (fs2/Fs)*2*pi  ;
As = 67;
tr_width_1 = ws1 - wp1;
tr_width_2 = ws2 - wp2;
M = ceil(11*pi/tr_width_1) + 1;
n = [0 : 1 : M-1];
wc1 = (ws1+wp1)/2;          % Ideal LPF cutoff frequency 
wc2 = (ws2+wp2)/2;          % Ideal LPF cutoff frequency

hd = ideal_lp(wc1, M) - ideal_lp(wc2, M);
w_black = (blackman(M))';
h = hd .* w_black;

[db, mag, pha, grd, w] = freqz_m(h, [1]);

% Convolution of Impulse response and Input gives Filtered Output Audio

FILTER = conv(X, h);        % Convolution of Impulse Response and Input
sound(FILTER, FS);          % To hear filtered audio signal

subplot(3, 2, 5)
plot(FILTER)
title('Filtered Audio')
xlabel('Time')
ylabel('Amplitude')

% FFT OF FILTERED AUDIO SIGNAL

N_Filter = length(FILTER);
F_Axis_Filter = 0 : (N_Filter-1)*FS/N_Filter;
FFT = fft(FILTER, N_Filter);
F0 = (-N_Filter/2 : N_Filter/2-1) .* (FS/N_Filter);
Y0 = fftshift(FFT);
AY0 = abs(Y0);

subplot(3, 2, 6)
plot(F0, AY0)
title('FFT-Filtered Audio')
xlabel('Frequency(Hz)')
ylabel('Amplitude')

% Creating Filtered Audio in File

audiowrite('Filtered_6E.m4a', FILTER, FS);